package com.bade.passwordresetapi.service;

import org.springframework.stereotype.Service;

import java.security.SecureRandom;

@Service
public class RandomPasswordGeneratorService {

    public String randomPasswordGenerator(int length) {

        return generateRandomPassword(length);
    }

    // active directory gidelecek olan servis yazılması lazım. Gelen veriyi yukarıyada fonksiyon gibi reset edilen yere paslıyacaz!

    private static final String UPPERCASE_LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final String LOWERCASE_LETTERS = "abcdefghijklmnopqrstuvwxyz";
    private static final String DIGITS = "0123456789";
    private static final String SPECIAL_CHARACTERS = "!@#$%^&*_+-=|;:,.<>?";

    private static final SecureRandom random = new SecureRandom();

    public static String generateRandomPassword(int length) {
        // Ensure that the password length is at least 8 to accommodate one character from each set
        if (length < 8) {
            throw new IllegalArgumentException("Password length must be at least 8.");
        }
SS
        // Create a StringBuilder to build the password
        StringBuilder password = new StringBuilder();

        // Add at least one character from each set
        password.append(randomCharacter(UPPERCASE_LETTERS));
        password.append(randomCharacter(LOWERCASE_LETTERS));
        password.append(randomCharacter(DIGITS));
        password.append(randomCharacter(SPECIAL_CHARACTERS));

        // Generate the remaining characters randomly
        for (int i = 4; i < length; i++) {
            String characterSet = selectCharacterSet();
            password.append(randomCharacter(characterSet));
        }

        // Shuffle the characters in the password
        String shuffledPassword = shuffleString(password.toString());

        return shuffledPassword;
    }

    private static char randomCharacter(String characterSet) {
        int randomIndex = random.nextInt(characterSet.length());
        return characterSet.charAt(randomIndex);
    }

    private static String selectCharacterSet() {
        // Randomly select a character set
        int randomIndex = random.nextInt(4);
        switch (randomIndex) {
            case 0:
                return UPPERCASE_LETTERS;
            case 1:
                return LOWERCASE_LETTERS;
            case 2:
                return DIGITS;
            default:
                return SPECIAL_CHARACTERS;
        }
    }

    private static String shuffleString(String input) {
        // Convert the string to a char array for shuffling
        char[] characters = input.toCharArray();

        // Fisher-Yates shuffle algorithm
        for (int i = characters.length - 1; i > 0; i--) {
            int j = random.nextInt(i + 1);
            char temp = characters[i];
            characters[i] = characters[j];
            characters[j] = temp;
        }

        return new String(characters);
    }

    public boolean isPasswordLengthValid(String password, int minLength, int maxLength) {
        int length = password.length();
        return length >= minLength && length <= maxLength;
    }

    public boolean isPasswordComplex(String password) {
        // Example: Require at least one uppercase letter, one lowercase letter, one digit, and one special character
        return password.matches("^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@#$%^&+=!]).+$");
    }
}
