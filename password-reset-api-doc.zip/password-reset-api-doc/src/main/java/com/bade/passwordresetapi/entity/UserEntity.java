package com.bade.passwordresetapi.entity;

import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class UserEntity {

    @Id
    private String tckn;

    private String uid;

    private String username;

    private String name;

    private String surname;

    private LocalDateTime registerDate;

    private LocalDateTime lastUpdatedDate;


}
