package com.bade.passwordresetapi.service;

import com.bade.passwordresetapi.entity.UserEntity;
import com.bade.passwordresetapi.exception.AuthenticationException;
import com.bade.passwordresetapi.exception.PasswordException;
import com.bade.passwordresetapi.model.UserAuthInfo;
import com.bade.passwordresetapi.model.UserResetRequest;
import com.bade.passwordresetapi.repository.UserRepository;
import lombok.AllArgsConstructor;

import lombok.SneakyThrows;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Objects;
import java.util.Optional;

@Service
@AllArgsConstructor
public class AuthService {

    private final UserRepository userRepository;

    private final RandomPasswordGeneratorService randomPasswordGeneratorService;

    private final ActiveDirectoryService activeDirectoryService;

    @SneakyThrows
    public UserAuthInfo resetPassword(UserResetRequest request) {


        Boolean isUserFindInDatabase = Boolean.FALSE;
        UserEntity currentUser = new UserEntity();
        if (Objects.nonNull(request.getTckn())) {
            Optional<UserEntity> list = userRepository.findById(request.getTckn());

            if (list.isPresent()) {
                currentUser = list.get();
                currentUser.setLastUpdatedDate(LocalDateTime.now());
                isUserFindInDatabase = Boolean.TRUE;
                userRepository.save(currentUser);
            }
        }

        else if (Objects.nonNull(request.getUsername())) {
            currentUser = userRepository.usernameInfo(request.getUsername());

            if (Objects.nonNull(currentUser)) {

                currentUser.setUsername(request.getUsername());
                currentUser.setLastUpdatedDate(LocalDateTime.now());
                isUserFindInDatabase = Boolean.TRUE;
                userRepository.save(currentUser);
            }
        }

        if (Boolean.TRUE.equals(isUserFindInDatabase)) {
            String randomPasswordGenerator = randomPasswordGeneratorService.randomPasswordGenerator(11);

            activeDirectoryService.newConnection();
            Boolean isActiveDirectorySuccessfully = activeDirectoryService.powerShell(randomPasswordGenerator);

            // TODO GEREKİRSE EXAMPLE - 2 için açılacak
            //Boolean isActiveDirectoryWithOldPassword = activeDirectoryService.powerShellResetWithOldPass(randomPasswordGenerator);

            return UserAuthInfo.builder()
                    .username(currentUser.getUsername())
                    .newPassword(isActiveDirectorySuccessfully ? randomPasswordGenerator : null)
                    .registerDate(currentUser.getRegisterDate())
                    .registerDate(currentUser.getLastUpdatedDate())
                    .name(currentUser.getName())
                    .surname(currentUser.getSurname())
                    .build();
        }

       throw new Exception("Kullanıcı bulunamadı!");
    }
}
