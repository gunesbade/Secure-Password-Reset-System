package com.bade.passwordresetapi.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.naming.AuthenticationException;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Hashtable;
import java.util.Properties;

@Service
@Slf4j
public class ActiveDirectoryService {

    DirContext connection;


    public void newConnection() {
        Properties env = new Properties();
        env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        env.put(Context.PROVIDER_URL, "ldap://URL");
        env.put(Context.SECURITY_PRINCIPAL, "uid=uid, ou=ou, dc=dc, dc=dc_local");
        env.put(Context.SECURITY_CREDENTIALS, "Enter Password");
        try {
            connection = new InitialDirContext(env);
            System.out.println("Connection is start; " + connection);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ex.printStackTrace();
        }
    }

    public Boolean powerShell(String password) {
        try {
            // PowerShell komutunu oluşturun
            String powerShellCommand = "$securePassword = ConvertTo-SecureString -String \"" + password + "\" -AsPlainText -Force -Verbose; " +
                    "Set-ADAccountPassword -Identity 'CN=USERNAME,OU=MT,OU=OU_USER,OU=OU_GROUP,DC=dc,DC=dc_local' -Reset -NewPassword $securePassword -PassThru";
            // TODO ShellCommand 46 satırda olan kod 43+44 power shell çıktınısın gösteren koddur. 46 satırda basılan shell komut uygulamanın 47 ve 48 de uygulamadan reset yapıldığında konsolda basılacaktır. Konsol üzerinden en son test'in shell komutu alınır.
            // $securePassword = ConvertTo-SecureString -String "4c5BN!X53*D" -AsPlainText -Force -Verbose; Set-ADAccountPassword -Identity 'CN=USERNAME,OU=MT,OU=OU_USER,OU=OU_GROUP,DC=dc,DC=dc_local' -Reset -NewPassword $securePassword -PassThru
            System.out.println(powerShellCommand);
            log.info("Power Shell command: " + powerShellCommand);

            // ProcessBuilder kullanarak PowerShell komutunu başlatın
            ProcessBuilder processBuilder = new ProcessBuilder("powershell.exe", "-Command", powerShellCommand);

            // Çalıştırılan komutun çıktısını almak için giriş akışını okuyun
            processBuilder.redirectErrorStream(true);

            Process process = processBuilder.start();
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;

            // Komutun çıktısını okuyun ve yazdırın
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
                log.info(line);
                // Eğer komutun çıktısında belirli bir başarı işareti varsa, başarı durumunu belirleyebilirsiniz
                if (line.contains("SuccessMessage")) {
                    return true;
                }
            }

            // Komutun tamamlanmasını bekleyin
            int exitCode = process.waitFor();
            System.out.println("Çıkış Kodu: " + exitCode);

            // Çıkış kodunu kullanarak başarı durumunu belirleyebilirsiniz
            if (exitCode == 0) {
                return true;
            } else {
                return false;
            }

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
            return false;
        }
    }

    // https://learn.microsoft.com/en-us/powershell/module/activedirectory/set-adaccountpassword?view=windowsserver2022-ps Example - 2 Metod
    public Boolean powerShellResetWithOldPass(String password) {
        try {
            // PowerShell komutunu oluşturun
            String powerShellCommand = "$securePassword = ConvertTo-SecureString -String \"" + password + "\" -AsPlainText -Force -Verbose; " +
                    "Set-ADAccountPassword -Identity 'CN=USERNAME,OU=MT,OU=OU_USER,OU=OU_GROUP,DC=dc,DC=dc_local' -OldPassword (ConvertTo-SecureString -AsPlainText \"p@ssw0rd\" -Force) -NewPassword $securePassword -PassThru";
            // TODO ShellCommand 93 satırda olan kod 90+91 power shell çıktınısın gösteren koddur. Aşağıda uygulama 94 ve 95 de tekrardan çalışırsa yeni shell komutlarını konsola yazar.
            // $securePassword = ConvertTo-SecureString -String "&Hkh69HQC-K" -AsPlainText -Force -Verbose; Set-ADAccountPassword -Identity 'CN=USERNAME,OU=MT,OU=OU_USER,OU=OU_GROUP,DC=dc,DC=dc_local' -OldPassword (ConvertTo-SecureString -AsPlainText "p@ssw0rd" -Force) -NewPassword $securePassword -PassThru
            System.out.println(powerShellCommand);
            log.info("Power Shell command (powerShellResetWithOldPass): " + powerShellCommand);

            // ProcessBuilder kullanarak PowerShell komutunu başlatın
            ProcessBuilder processBuilder = new ProcessBuilder("powershell.exe", "-Command", powerShellCommand);

            // Çalıştırılan komutun çıktısını almak için giriş akışını okuyun
            processBuilder.redirectErrorStream(true);

            Process process = processBuilder.start();
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;

            // Komutun çıktısını okuyun ve yazdırın
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
                log.info(line);
                // Eğer komutun çıktısında belirli bir başarı işareti varsa, başarı durumunu belirleyebilirsiniz
                if (line.contains("SuccessMessage")) {
                    return true;
                }
            }

            // Komutun tamamlanmasını bekleyin
            int exitCode = process.waitFor();
            System.out.println("Çıkış Kodu: " + exitCode);

            // Çıkış kodunu kullanarak başarı durumunu belirleyebilirsiniz
            if (exitCode == 0) {
                return true;
            } else {
                return false;
            }

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
            return false;
        }
    }

}
