package com.bade.passwordresetapi.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserResetRequest {

    private String tckn;

    private String username;

}
