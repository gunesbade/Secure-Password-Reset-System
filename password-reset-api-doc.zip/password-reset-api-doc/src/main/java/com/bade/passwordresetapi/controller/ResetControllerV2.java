package com.bade.passwordresetapi.controller;

import com.bade.passwordresetapi.model.UserAuthInfo;
import com.bade.passwordresetapi.model.UserResetRequest;
import com.bade.passwordresetapi.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@RequiredArgsConstructor
@Controller
@RequestMapping("/public")
public class ResetControllerV2 {

    private final AuthService authService;

    @GetMapping("/user-info")
    public String getUserInfo(){
        return "user-info";
    }

    @PostMapping("/user-detail-info")
    public String userInfo(@RequestParam("tckn") String tckn, @RequestParam("username") String username, Model model) {

        UserResetRequest userResetRequest = new UserResetRequest();
        userResetRequest.setTckn(tckn);
        userResetRequest.setUsername(username);

        UserAuthInfo userAuthInfo = authService.resetPassword(userResetRequest);

        model.addAttribute("newPassword", userAuthInfo.getNewPassword());

        return "resetpassword-success";
    }
}
