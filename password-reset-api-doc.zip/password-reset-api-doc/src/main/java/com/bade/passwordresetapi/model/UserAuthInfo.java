package com.bade.passwordresetapi.model;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class UserAuthInfo {

    private String username;

    private LocalDateTime registerDate;

    private LocalDateTime lastUpdatedDate;

    private String name;

    private String surname;

    private String newPassword;

    private Boolean isAuthenticationSuccess;

}
