package com.bade.passwordresetapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PasswordResetApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PasswordResetApiApplication.class, args);
	}

}
